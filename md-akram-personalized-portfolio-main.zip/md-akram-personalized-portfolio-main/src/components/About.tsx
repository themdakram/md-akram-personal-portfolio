
import { GraduationCap, Building, Calendar, Download } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const About = () => {
  const handleResumeDownload = () => {
    const link = document.createElement('a');
    link.href = '/lovable-uploads/fd0b522b-c93b-457b-84c0-65d98b4ba57d.png';
    link.download = 'MD_AKRAM_Resume.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section id="about" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            About <span className="text-primary">Me</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Get to know more about my journey, education, and passion for technology
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="animate-slide-in-left">
            <div className="prose prose-lg text-muted-foreground max-w-none">
              <p className="mb-6">
                My name is <span className="text-primary font-semibold">Md Akram</span>. I've recently completed a B.Tech in Information Technology (2025) with a CGPA of 8.14. I have strong academic grounding in core areas like Data Structures, Operating Systems, and Database Management.
              </p>
              <p className="mb-6">
                I had the opportunity to intern at <span className="text-primary font-semibold">UR Rao Satellite Center (ISRO)</span>, where I worked on synchronization mechanisms using semaphores and shared memory in C, optimizing real-time performance in multicore systems.
              </p>
              <p className="mb-6">
                I started my software journey from photography. Through that, I learned to love the process of creating from scratch. Since then, this has led me to software development as it fulfills my love for learning and building things.
              </p>
            </div>

            {/* Resume Download Button */}
            <div className="mt-8">
              <Button 
                onClick={handleResumeDownload}
                className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
                size="lg"
              >
                <Download className="h-4 w-4 mr-2" />
                Download My Resume
              </Button>
            </div>
          </div>

          {/* Education Card */}
          <div className="animate-fade-in">
            <Card className="bg-gradient-surface border-border shadow-card hover:shadow-elegant transition-all duration-300">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="p-3 rounded-full bg-primary/20">
                    <GraduationCap className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-display font-semibold text-xl">Education</h3>
                    <p className="text-muted-foreground">Academic Background</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* B.Tech */}
                  <div className="border-l-2 border-primary pl-6 relative">
                    <div className="absolute -left-2 top-0 w-4 h-4 bg-primary rounded-full"></div>
                    <div className="flex items-center gap-2 mb-2">
                      <Building className="h-4 w-4 text-primary" />
                      <span className="font-semibold">Calcutta Institute of Engineering and Management</span>
                    </div>
                    <div className="text-muted-foreground mb-2">B.Tech in Information Technology</div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>2021 - 2025</span>
                        </div>
                      <div className="px-2 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
                        CGPA: 8.14
                      </div>
                    </div>
                  </div>

                  {/* Higher Secondary */}
                  <div className="border-l-2 border-muted pl-6 relative">
                    <div className="absolute -left-2 top-0 w-4 h-4 bg-muted rounded-full"></div>
                    <div className="flex items-center gap-2 mb-2">
                      <Building className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">RSB +2 School Samastipur</span>
                    </div>
                    <div className="text-muted-foreground mb-2">Higher Secondary School (BSEB)</div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>2018 - 2020</span>
                      </div>
                      <div className="px-2 py-1 bg-muted/20 text-muted-foreground rounded-full text-xs font-medium">
                        74%
                      </div>
                    </div>
                  </div>

                  {/* Secondary School */}
                  <div className="border-l-2 border-muted pl-6 relative">
                    <div className="absolute -left-2 top-0 w-4 h-4 bg-muted rounded-full"></div>
                    <div className="flex items-center gap-2 mb-2">
                      <Building className="h-4 w-4 text-muted-foreground" />
                      <span className="font-semibold">Sadhna Devi Vidyapith Samastipur</span>
                    </div>
                    <div className="text-muted-foreground mb-2">Secondary School Examination (CBSE)</div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        <span>2017 - 2018</span>
                      </div>
                      <div className="px-2 py-1 bg-muted/20 text-muted-foreground rounded-full text-xs font-medium">
                        70.6%
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
