import { ExternalLink, Github, BarChart3, Globe, Smartphone, Play } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Projects = () => {
  const projects = [
    {
      title: "Sales Insight Dashboard",
      description: "A comprehensive business intelligence dashboard built using Power BI and MySQL Workbench. Implemented advanced ETL processes and automation that resulted in a 10% cost reduction and saved 20% of analysts' time.",
      image: "/api/placeholder/400/250",
      tech: ["Power BI", "MySQL", "ETL", "Business Intelligence"],
      features: [
        "Interactive Sales Analytics",
        "Automated Data Processing",
        "Real-time Performance Metrics",
        "Cost Optimization Insights"
      ],
      icon: BarChart3,
      color: "from-blue-500 to-cyan-500",
      impact: {
        cost: "10% Cost Reduction",
        time: "20% Time Saved",
        efficiency: "Enhanced Analytics"
      }
    },
    {
      title: "Instagram Clone",
      description: "A fully functional Instagram clone featuring user authentication, photo sharing, real-time comments, and social interactions. Built with modern web technologies focusing on responsive design and user experience.",
      image: "/api/placeholder/400/250", 
      tech: ["HTML", "CSS", "JavaScript", "Responsive Design"],
      features: [
        "User Authentication System",
        "Photo Upload & Sharing",
        "Real-time Comments",
        "Responsive Mobile Design"
      ],
      icon: Smartphone,
      color: "from-pink-500 to-rose-500",
      demo: "https://pbfe0g.csb.app/"
    },
    {
      title: "Google Drive Clone",
      description: "A cloud storage solution mimicking Google Drive's core functionalities including file upload, organization, sharing, and collaborative features. Implemented with modern web technologies.",
      image: "/api/placeholder/400/250",
      tech: ["HTML", "CSS", "JavaScript", "Local Storage"],
      features: [
        "File Upload & Management",
        "Folder Organization",
        "File Sharing System",
        "Search Functionality"
      ],
      icon: Globe,
      color: "from-green-500 to-emerald-500",
      demo: "https://gbckmx.csb.app/"
    },
    {
      title: "Hotstar Clone",
      description: "A streaming platform clone featuring video playback, content categorization, user profiles, and responsive design. Recreated the user interface and key functionalities of the popular streaming service.",
      image: "/api/placeholder/400/250",
      tech: ["HTML", "CSS", "JavaScript", "Video API"],
      features: [
        "Video Streaming Interface",
        "Content Categorization", 
        "User Profile System",
        "Responsive Video Player"
      ],
      icon: Play,
      color: "from-purple-500 to-indigo-500",
      demo: "https://9ngyho.csb.app/"
    }
  ];

  return (
    <section id="projects" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            Featured <span className="text-primary">Projects</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A showcase of my technical skills and creative problem-solving abilities
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card 
              key={project.title}
              className="bg-gradient-surface border-border shadow-card hover:shadow-elegant transition-all duration-300 group animate-fade-in overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-0">
                {/* Project Image */}
                <div className="relative h-48 bg-gradient-to-r from-gray-800 to-gray-900 overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-transparent z-10"></div>
                  <div className={`absolute inset-0 bg-gradient-to-r ${project.color} opacity-20`}></div>
                  <div className="absolute top-4 left-4 z-20">
                    <div className={`p-2 rounded-lg bg-gradient-to-r ${project.color} bg-opacity-90`}>
                      <project.icon className="h-6 w-6 text-white" />
                    </div>
                  </div>
                  {project.impact && (
                    <div className="absolute top-4 right-4 z-20 space-y-1">
                      <div className="px-2 py-1 bg-primary/90 text-white rounded text-xs font-medium">
                        {project.impact.cost}
                      </div>
                      <div className="px-2 py-1 bg-accent/90 text-white rounded text-xs font-medium">
                        {project.impact.time}
                      </div>
                    </div>
                  )}
                  <div className="absolute bottom-4 left-4 z-20">
                    <h3 className="font-display font-bold text-2xl text-white mb-2">
                      {project.title}
                    </h3>
                  </div>
                </div>

                {/* Project Content */}
                <div className="p-6">
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Features */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-primary mb-3">Key Features:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {project.features.map((feature) => (
                        <div key={feature} className="flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-primary rounded-full flex-shrink-0"></div>
                          <span className="text-sm text-muted-foreground">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Tech Stack */}
                  <div className="mb-6">
                    <div className="flex flex-wrap gap-2">
                      {project.tech.map((tech) => (
                        <span
                          key={tech}
                          className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium border border-primary/20"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-3">
                    {project.demo && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="flex-1"
                        onClick={() => window.open(project.demo, '_blank')}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Demo
                      </Button>
                    )}
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="flex-1"
                    >
                      <Github className="h-4 w-4 mr-2" />
                      Source Code
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16 animate-fade-in">
          <div className="bg-gradient-surface rounded-2xl p-8 border border-border shadow-card max-w-2xl mx-auto">
            <h3 className="font-display font-bold text-2xl mb-4">
              Interested in My Work?
            </h3>
            <p className="text-muted-foreground mb-6">
              These projects represent just a glimpse of what I can create. Let's discuss your next project!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                onClick={() => window.open("https://github.com/themdakram", '_blank')}
                className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
              >
                <Github className="h-4 w-4 mr-2" />
                View All Projects
              </Button>
              <Button 
                variant="outline"
                onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
              >
                Let's Collaborate
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;