import { Rocket, Calendar, MapPin, FileText } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Experience = () => {
  const handleCertificateView = () => {
    const certificateUrl = '/lovable-uploads/e76bdd70-5966-47c5-98c3-77c115bd0a2e.png';
    console.log('Opening certificate URL:', certificateUrl);
    window.open(certificateUrl, '_blank');
  };
  return (
    <section id="experience" className="py-20 px-4 bg-surface/50">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            Work <span className="text-primary">Experience</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            My professional journey and contributions to real-world projects
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="bg-gradient-surface border-border shadow-card hover:shadow-elegant transition-all duration-300 animate-fade-in">
            <CardContent className="p-8">
              <div className="flex flex-col md:flex-row gap-6">
                {/* Icon and Company */}
                <div className="flex-shrink-0">
                  <div className="p-4 rounded-full bg-primary/20 inline-block">
                    <Rocket className="h-8 w-8 text-primary" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                    <div>
                      <h3 className="font-display font-bold text-2xl mb-2">
                        Intern - <span className="text-primary">UR Rao Satellite Center (ISRO)</span>
                      </h3>
                      <p className="text-muted-foreground font-medium">Software Development Intern</p>
                    </div>
                    <div className="flex flex-col md:items-end gap-2 mt-4 md:mt-0">
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <Calendar className="h-4 w-4 text-primary" />
                        <span>July 1 – August 14, 2024</span>
                      </div>
                      <div className="flex items-center gap-2 text-muted-foreground">
                        <MapPin className="h-4 w-4 text-primary" />
                        <span>Bangalore, India</span>
                      </div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-semibold text-lg mb-3 text-primary">
                      Multi Core Execution Protocol for Instruction Level Simulators
                    </h4>
                    <p className="text-muted-foreground mb-4">
                      Developed and implemented advanced synchronization mechanisms to optimize real-time performance in multicore systems, contributing to critical space technology infrastructure.
                    </p>
                  </div>

                  {/* Key Achievements */}
                  <div>
                    <h4 className="font-semibold mb-3">Key Achievements:</h4>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-muted-foreground">
                          Implemented synchronization mechanisms using semaphores and shared memory in C programming language
                        </span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-muted-foreground">
                          Optimized real-time performance in multicore systems for satellite technology applications
                        </span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-muted-foreground">
                          Contributed to instruction level simulator development for space missions
                        </span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-muted-foreground">
                          Gained hands-on experience with mission-critical software development practices
                        </span>
                      </li>
                    </ul>
                  </div>

                  {/* Certificate Button */}
                  <div className="mt-6 pt-6 border-t border-border">
                    <Button 
                      onClick={handleCertificateView}
                      variant="outline"
                      className="bg-primary/10 hover:bg-primary/20 border-primary/30"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      View Internship Certificate
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default Experience;