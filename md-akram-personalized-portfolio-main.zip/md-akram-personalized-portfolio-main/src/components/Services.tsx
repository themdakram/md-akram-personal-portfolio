import { BarChart3, Code, Database, Globe, Cpu, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const Services = () => {
  const services = [
    {
      icon: BarChart3,
      title: "Data Analytics",
      description: "Offering comprehensive data analysis services using tools like Power BI and MySQL to create meaningful dashboards, reports, and data pipelines for better business insights.",
      features: [
        "Interactive Dashboard Creation",
        "ETL Process Implementation", 
        "Business Intelligence Reporting",
        "Data Visualization & Insights"
      ],
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Code,
      title: "Web Development",
      description: "Building responsive and modern web applications using cutting-edge technologies like React, JavaScript, and modern CSS frameworks.",
      features: [
        "Responsive Web Design",
        "Frontend Development",
        "UI/UX Implementation",
        "Performance Optimization"
      ],
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Database,
      title: "Database Solutions",
      description: "Designing and optimizing database systems for efficient data storage, retrieval, and management using MySQL and modern database practices.",
      features: [
        "Database Design & Modeling",
        "Query Optimization",
        "Data Migration Services",
        "Performance Tuning"
      ],
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Cpu,
      title: "System Optimization",
      description: "Leveraging experience from ISRO internship to optimize system performance, implement synchronization mechanisms, and enhance multicore processing.",
      features: [
        "Performance Analysis",
        "System Architecture Design",
        "Multicore Optimization",
        "Real-time System Development"
      ],
      color: "from-orange-500 to-red-500"
    }
  ];

  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="services" className="py-20 px-4 bg-surface/50">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            My <span className="text-primary">Services</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Comprehensive solutions for your data analytics and development needs
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => (
            <Card 
              key={service.title}
              className="bg-gradient-surface border-border shadow-card hover:shadow-elegant transition-all duration-300 group animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${service.color} bg-opacity-20`}>
                    <service.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-display font-bold text-2xl group-hover:text-primary transition-colors duration-300">
                    {service.title}
                  </h3>
                </div>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>

                <div className="space-y-3">
                  <h4 className="font-semibold text-primary">Key Features:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3">
                        <div className="w-2 h-2 bg-primary rounded-full flex-shrink-0"></div>
                        <span className="text-muted-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center animate-fade-in">
          <div className="bg-gradient-surface rounded-2xl p-8 border border-border shadow-card max-w-2xl mx-auto">
            <TrendingUp className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="font-display font-bold text-2xl mb-4">
              Ready to Transform Your Data?
            </h3>
            <p className="text-muted-foreground mb-6">
              Let's discuss how I can help you unlock insights from your data and build powerful solutions for your business.
            </p>
            <Button 
              onClick={scrollToContact}
              className="bg-gradient-primary hover:shadow-glow transition-all duration-300"
              size="lg"
            >
              Get Started Today
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;