import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, Phone } from "lucide-react";

const Hero = () => {
  const scrollToContact = () => {
    const element = document.querySelector("#contact");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const scrollToProjects = () => {
    const element = document.querySelector("#projects");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-surface opacity-50"></div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-primary/20 rounded-full blur-xl animate-float"></div>
      <div className="absolute bottom-20 right-10 w-32 h-32 bg-accent/20 rounded-full blur-xl animate-float" style={{ animationDelay: '1s' }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="text-center lg:text-left animate-slide-in-left">
            <div className="mb-6">
              <span className="text-accent font-medium text-lg mb-2 block">Hello 👋</span>
              <h1 className="font-display font-bold text-4xl md:text-6xl lg:text-7xl mb-4">
                I'm <span className="text-primary">Md Akram</span>
              </h1>
              <h2 className="font-display font-semibold text-2xl md:text-3xl text-muted-foreground mb-6">
                Aspiring IT Professional | Software Engineer
              </h2>
            </div>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl">
              Hi, I'm Md Akram, a B.Tech graduate in Information Technology from Calcutta Institute of Engineering and Management. 
              I specialize in data analytics and development, with experience in real-time systems and business insights.
            </p>

            {/* Contact Info */}
            <div className="flex flex-wrap gap-4 mb-8 justify-center lg:justify-start">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="h-4 w-4 text-primary" />
                <span className="text-sm">mohammedakramintern@gmail.com</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Phone className="h-4 w-4 text-primary" />
                <span className="text-sm">+91 8207455859</span>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={scrollToProjects}
                className="bg-gradient-primary hover:shadow-glow transition-all duration-300 font-semibold"
                size="lg"
              >
                View My Work
              </Button>
              <Button 
                onClick={scrollToContact}
                variant="outline" 
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                size="lg"
              >
                Contact Me
              </Button>
            </div>

            {/* Social Links */}
            <div className="flex gap-4 mt-8 justify-center lg:justify-start">
              <a 
                href="https://github.com/themdakram" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-card hover:bg-surface-hover hover:shadow-glow transition-all duration-300 group"
              >
                <Github className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
              </a>
              <a 
                href="https://linkedin.com/in/md-akram-331284229" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-card hover:bg-surface-hover hover:shadow-glow transition-all duration-300 group"
              >
                <Linkedin className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
              </a>
            </div>
          </div>

          {/* Profile Image */}
          <div className="flex justify-center lg:justify-end animate-fade-in">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-primary rounded-full blur-2xl opacity-30 animate-glow-pulse"></div>
              <div className="relative w-96 h-96 md:w-[28rem] md:h-[28rem] rounded-full overflow-hidden border-4 border-primary/30 shadow-elegant">
                <img 
                  src="/lovable-uploads/27dcac4a-460f-4dce-878d-236fa5e44af3.png" 
                  alt="Md Akram - Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Floating Tech Icons */}
              <div className="absolute -top-4 -right-4 bg-card p-3 rounded-full animate-float shadow-card">
                <span className="text-2xl">💻</span>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-card p-3 rounded-full animate-float shadow-card" style={{ animationDelay: '1.5s' }}>
                <span className="text-2xl">📊</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
