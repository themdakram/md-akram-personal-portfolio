import { Github, Linkedin, Mail, Heart } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      icon: Github,
      href: "https://github.com/themdakram",
      label: "GitHub"
    },
    {
      icon: Linkedin,
      href: "https://linkedin.com/in/md-akram-331284229",
      label: "LinkedIn"
    },
    {
      icon: Mail,
      href: "mailto:mohammedakramintern@gmail.com",
      label: "Email"
    }
  ];

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-surface border-t border-border">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8 items-center">
          {/* Branding */}
          <div className="text-center md:text-left">
            <button 
              onClick={scrollToTop}
              className="font-display font-bold text-2xl text-primary hover:text-primary-glow transition-colors duration-300"
            >
              Md Akram
            </button>
            <p className="text-muted-foreground mt-2">
              Aspiring IT Professional & Data Analyst
            </p>
          </div>

          {/* Social Links */}
          <div className="flex justify-center gap-4">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-3 rounded-full bg-card hover:bg-surface-hover transition-all duration-300 group hover:shadow-glow"
                aria-label={social.label}
              >
                <social.icon className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:scale-110 transition-all duration-300" />
              </a>
            ))}
          </div>

          {/* Copyright */}
          <div className="text-center md:text-right">
            <p className="text-muted-foreground text-sm">
              © {currentYear} Md Akram. All rights reserved.
            </p>
            <p className="text-muted-foreground text-sm mt-1 flex items-center justify-center md:justify-end gap-1">
              Made with <Heart className="h-3 w-3 text-red-500 animate-pulse" /> in India
            </p>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-border mt-8 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <div>
              <span>Building the future, one line of code at a time.</span>
            </div>
            <div className="flex gap-6">
              <button 
                onClick={() => document.querySelector("#about")?.scrollIntoView({ behavior: "smooth" })}
                className="hover:text-primary transition-colors duration-300"
              >
                About
              </button>
              <button 
                onClick={() => document.querySelector("#projects")?.scrollIntoView({ behavior: "smooth" })}
                className="hover:text-primary transition-colors duration-300"
              >
                Projects
              </button>
              <button 
                onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
                className="hover:text-primary transition-colors duration-300"
              >
                Contact
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;