
import { Code, Database, BarChart3, Globe, Cpu, Settings } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const Skills = () => {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: Code,
      skills: [
        { name: "Java", level: 85 },
        { name: "C/C++", level: 80 },
        { name: "Python", level: 70 }
      ]
    },
    {
      title: "Database & Analytics",
      icon: Database,
      skills: [
        { name: "MySQL", level: 90 },
        { name: "Power BI", level: 85 },
        { name: "Data Analysis", level: 80 },
        { name: "ETL Processes", level: 75 }
      ]
    },
    {
      title: "Web Technologies",
      icon: Globe,
      skills: [
        { name: "HTML/CSS", level: 90 }
      ]
    },
    {
      title: "System & Tools",
      icon: Settings,
      skills: [
        { name: "Operating Systems", level: 85 },
        { name: "Data Structures", level: 90 },
        { name: "Git/Version Control", level: 80 },
        { name: "Agile Methodologies", level: 75 }
      ]
    }
  ];

  const technologies = [
    "Java", "MySQL", "Power BI", "HTML", "CSS", 
    "C/C++", "Data Structures", "Operating Systems", "Database Management",
    "ETL", "Data Analysis", "Git", "Linux"
  ];

  return (
    <section id="skills" className="py-20 px-4">
      <div className="container mx-auto">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="font-display font-bold text-4xl md:text-5xl mb-4">
            Technical <span className="text-primary">Skills</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Technologies and tools I work with to bring ideas to life
          </p>
        </div>

        {/* Skill Categories */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {skillCategories.map((category, index) => (
            <Card 
              key={category.title} 
              className="bg-gradient-surface border-border shadow-card hover:shadow-elegant transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="p-2 rounded-lg bg-primary/20">
                    <category.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="font-display font-semibold text-xl">{category.title}</h3>
                </div>
                
                <div className="space-y-4">
                  {category.skills.map((skill) => (
                    <div key={skill.name}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{skill.name}</span>
                        <span className="text-sm text-muted-foreground">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div 
                          className="bg-gradient-primary h-2 rounded-full transition-all duration-1000 ease-out"
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Technology Tags */}
        <div className="text-center animate-fade-in">
          <h3 className="font-display font-semibold text-2xl mb-8">Technologies I Work With</h3>
          <div className="flex flex-wrap justify-center gap-3 max-w-4xl mx-auto">
            {technologies.map((tech, index) => (
              <span
                key={tech}
                className="px-4 py-2 bg-card border border-border rounded-full text-sm font-medium hover:bg-surface-hover hover:border-primary/50 transition-all duration-300 cursor-default animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                {tech}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
